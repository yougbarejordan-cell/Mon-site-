/* Fabi Ciné – catalogue en ligne (Google Apps Script, gratuit)
   Mode d'emploi : voir INSTALLER-CATALOGUE.txt */

// Choisissez un mot de passe de publication (différent de celui de l'admin si vous voulez)
const PASSWORD = "CHANGEZ-MOI";
const FILE = "fabi-cine-catalogue.json";

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function file_(create) {
  const it = DriveApp.getFilesByName(FILE);
  if (it.hasNext()) return it.next();
  return create ? DriveApp.createFile(FILE, "{}", MimeType.PLAIN_TEXT) : null;
}

// L'application des clients lit ici le catalogue
function doGet() {
  const f = file_(false);
  if (!f) return out_({ v: 0, items: null });
  return ContentService.createTextOutput(f.getBlob().getDataAsString("UTF-8")).setMimeType(ContentService.MimeType.JSON);
}

// Le bouton « Publier le site » de l'admin envoie ici le nouveau catalogue
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const d = JSON.parse(e.postData.contents);
    if (String(d.key) !== PASSWORD) return out_({ ok: false, error: "key" });
    if (!Array.isArray(d.items) || d.items.length < 1) return out_({ ok: false, error: "items" });
    const v = Number(d.v) || Date.now();
    file_(true).setContent(JSON.stringify({ v: v, items: d.items }));
    return out_({ ok: true, v: v });
  } catch (err) {
    return out_({ ok: false, error: "erreur" });
  } finally {
    lock.releaseLock();
  }
}
