/* Fabi Ciné – avis des clients automatiques (Google Sheets + Apps Script, gratuit)
   Mode d'emploi : voir INSTALLER-AVIS.txt */

// true  = chaque avis s'affiche tout de suite chez tout le monde
// false = l'avis reste caché jusqu'à ce que vous écriviez OUI dans la colonne « visible »
const AUTO_APPROVE = true;
const SHEET = "Avis";
const HEAD = ["date", "id", "nom", "note", "texte", "visible"];

function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET);
  if (!sh) { sh = ss.insertSheet(SHEET); sh.appendRow(HEAD); sh.setFrozenRows(1); }
  return sh;
}
function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
// Empêche qu'un texte commençant par = + - @ soit pris pour une formule
function safe_(t) { t = String(t || ""); return /^[=+\-@]/.test(t) ? "'" + t : t; }

// Les clients lisent ici les avis visibles
function doGet() {
  const rows = sheet_().getDataRange().getValues().slice(1);
  const avis = rows
    .filter(r => String(r[5]).trim().toUpperCase() === "OUI" && Number(r[3]) >= 1)
    .map(r => ({ nom: String(r[2] || "").replace(/^'/, ""), note: Number(r[3]), texte: String(r[4] || "").replace(/^'/, ""), date: r[0] }))
    .reverse().slice(0, 100);
  return out_({ avis: avis });
}

// Les clients envoient ici leur avis (1 avis par téléphone : un nouvel envoi remplace l'ancien)
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const d = JSON.parse(e.postData.contents);
    const note = Math.round(Number(d.note));
    const id = String(d.id || "").slice(0, 40);
    if (!(note >= 1 && note <= 5) || !id) return out_({ ok: false });
    const nom = safe_(String(d.nom || "").slice(0, 40));
    const texte = safe_(String(d.texte || "").slice(0, 400));
    const sh = sheet_();
    const data = sh.getDataRange().getValues();
    let row = -1;
    for (let i = 1; i < data.length; i++) { if (String(data[i][1]) === id) { row = i + 1; break; } }
    if (row > 0) {
      sh.getRange(row, 1, 1, 5).setValues([[new Date(), id, nom, note, texte]]);
    } else {
      sh.appendRow([new Date(), id, nom, note, texte, AUTO_APPROVE ? "OUI" : ""]);
    }
    return out_({ ok: true });
  } catch (err) {
    return out_({ ok: false });
  } finally {
    lock.releaseLock();
  }
}
